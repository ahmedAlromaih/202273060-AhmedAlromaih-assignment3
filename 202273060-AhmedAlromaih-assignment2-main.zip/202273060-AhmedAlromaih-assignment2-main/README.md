# Assignment 2 - Interactive Portfolio Website

This project is Ahmed Alromaih's Assignment 2 submission for SWE206. It extends the Assignment 1 portfolio with interactive features, JavaScript-based data handling, smoother user feedback, and improved documentation.

## Project Description

The website is a responsive personal portfolio built with HTML, CSS, and JavaScript. It includes interactive project filtering, theme preference saving with `localStorage`, contact form validation, and a clearer presentation of personal and project information.

## Features

- Responsive portfolio layout
- Dark and light theme toggle
- Theme preference saved with `localStorage`
- Dynamic greeting based on time of day
- Interactive project filtering by category
- Live project search while typing
- Contact form validation with success and error messages
- Smooth transitions and reveal animations
- Empty-state message when no projects match the search

## Project Structure

```text
.
|-- README.md
|-- index.html
|-- css/
|   `-- styles.css
|-- js/
|   `-- script.js
|-- images/
|   |-- profile-placeholder.svg
|   |-- project1-placeholder.svg
|   `-- project2-placeholder.svg
|-- docs/
|   |-- ai-usage-report.md
|   `-- technical-documentation.md
|-- projects/
|   `-- simple-program/
|       |-- README.md
|       `-- bmi_calculator.py
`-- .gitignore
```

## How to Run Locally

1. Download or clone the repository.
2. Open `index.html` in a modern browser.
3. Interact with the project filters, theme toggle, and contact form.
4. To run the BMI calculator:

```bash
py -3 projects/simple-program/bmi_calculator.py
```

If `py` is not available, try:

```bash
python projects/simple-program/bmi_calculator.py
```

## AI Use Summary

AI tools were used to help review the structure, improve JavaScript features, refine the layout, and rewrite documentation. The detailed report is available in [docs/ai-usage-report.md](docs/ai-usage-report.md).

## Technical Documentation

Technical details for the project are available in [docs/technical-documentation.md](docs/technical-documentation.md).

## Optional Deployment

This project can be deployed using GitHub Pages, Netlify, or Vercel.
