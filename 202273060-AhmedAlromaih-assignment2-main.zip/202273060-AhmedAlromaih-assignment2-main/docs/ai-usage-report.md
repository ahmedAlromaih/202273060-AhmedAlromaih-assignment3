# AI Usage Report

## AI Tools Used

### ChatGPT
- Helped review and improve the portfolio structure.
- Assisted with debugging broken paths, missing files, and styling issues.
- Suggested interactive JavaScript features such as project filtering, live search, and better user feedback.
- Helped rewrite portfolio content, README content, and technical documentation.

## How AI Was Used

AI was used as a support tool for:
- debugging and fixing code problems
- improving code structure and readability
- generating suggestions for interactivity and usability
- writing and refining documentation

## What Was Implemented With AI Support

- Theme toggle with `localStorage`
- Live project filter and search behavior
- Contact form validation and feedback
- Improved HTML/CSS alignment after accidental deletions
- Assignment 2 documentation and cleanup

## Responsible Use

- Every suggestion was reviewed before being added.
- The generated code was edited to match the actual project structure.
- Features were tested after each major change.
- AI was used to support learning and problem-solving, not to replace understanding.

## Understanding and Improvements

The AI-generated suggestions were modified to fit the project requirements, personal information, and assignment rubric. This included changing file paths, renaming classes, updating content, and adjusting the interface so it stayed functional and understandable.
