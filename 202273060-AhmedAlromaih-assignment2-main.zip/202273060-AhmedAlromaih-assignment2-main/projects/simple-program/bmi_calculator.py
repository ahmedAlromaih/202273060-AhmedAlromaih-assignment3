"""
BMI Calculator

- Reads weight in kilograms
- Reads height in centimeters
- Calculates BMI
- Prints the BMI category
"""


def read_positive_float(prompt: str) -> float:
    while True:
        raw = input(prompt).strip()
        try:
            value = float(raw)
            if value <= 0:
                print("Please enter a number greater than 0.")
                continue
            return value
        except ValueError:
            print("Invalid number. Try again, for example: 72.5")


def bmi_category(bmi: float) -> str:
    if bmi < 18.5:
        return "Underweight"
    if bmi < 25:
        return "Normal weight"
    if bmi < 30:
        return "Overweight"
    return "Obesity"


def main() -> None:
    print("=== BMI Calculator ===")
    weight = read_positive_float("Enter your weight in kg: ")
    height_cm = read_positive_float("Enter your height in cm: ")

    height_m = height_cm / 100
    bmi = weight / (height_m ** 2)

    print(f"\nYour BMI is: {bmi:.2f}")
    print(f"Category: {bmi_category(bmi)}")


if __name__ == "__main__":
    main()
