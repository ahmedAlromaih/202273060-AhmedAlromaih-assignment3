# Simple Program - BMI Calculator

This small Python program calculates Body Mass Index (BMI) from user input and prints the matching BMI category.

## How to Run

From the repository root:

```bash
py -3 projects/simple-program/bmi_calculator.py
```

If `py` is not available on your system, try:

```bash
python projects/simple-program/bmi_calculator.py
```
