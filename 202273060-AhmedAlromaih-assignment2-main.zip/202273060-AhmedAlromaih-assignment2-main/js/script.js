/* ==========================
   Helpers
========================== */
function $(id) { return document.getElementById(id); }

function setTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("theme", theme);

  const btn = $("themeToggle");
  if (btn) {
    const isLight = theme === "light";
    btn.setAttribute("aria-pressed", String(isLight));
    btn.innerHTML = isLight ? "Sun <span class='hide-sm'>Theme</span>" : "Moon <span class='hide-sm'>Theme</span>";
  }
}

function initTheme() {
  const saved = localStorage.getItem("theme");
  if (saved === "light" || saved === "dark") {
    setTheme(saved);
    return;
  }

  const prefersLight = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
  setTheme(prefersLight ? "light" : "dark");
}

function setGreeting() {
  const el = $("greeting");
  if (!el) return;

  const now = new Date();
  const hour = now.getHours();

  let msg = "Welcome!";
  if (hour >= 5 && hour < 12) msg = "Good morning";
  else if (hour >= 12 && hour < 17) msg = "Good afternoon";
  else if (hour >= 17 && hour < 22) msg = "Good evening";
  else msg = "Hello night owl";

  el.textContent = msg;
}

function setYear() {
  const y = $("year");
  if (y) y.textContent = String(new Date().getFullYear());
}

/* ==========================
   Mobile nav
========================== */
function initMobileNav() {
  const toggle = $("navToggle");
  const menu = $("navMenu");
  if (!toggle || !menu) return;

  toggle.addEventListener("click", () => {
    const isOpen = menu.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  menu.querySelectorAll("a").forEach((a) => {
    a.addEventListener("click", () => {
      if (menu.classList.contains("is-open")) {
        menu.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  });

  document.addEventListener("click", (e) => {
    const target = e.target;
    if (!menu.classList.contains("is-open")) return;
    if (target === toggle || menu.contains(target)) return;

    menu.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
  });
}

/* ==========================
   Theme toggle
========================== */
function initThemeToggle() {
  const btn = $("themeToggle");
  if (!btn) return;

  btn.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme") || "dark";
    setTheme(current === "dark" ? "light" : "dark");
  });
}

/* ==========================
   Project filters + search
========================== */
function initProjectFilters() {
  const search = $("projectSearch");
  const status = $("projectSearchStatus");
  const empty = $("projectsEmptyState");
  const buttons = Array.from(document.querySelectorAll(".filter-btn"));
  const cards = Array.from(document.querySelectorAll(".project-item"));

  if (!search || !status || !empty || buttons.length === 0 || cards.length === 0) return;

  let activeFilter = "all";

  function updateProjects() {
    const query = search.value.trim().toLowerCase();
    let visibleCount = 0;

    cards.forEach((card) => {
      const category = card.dataset.category || "";
      const title = card.dataset.title || "";
      const tags = card.dataset.tags || "";
      const haystack = `${title} ${tags}`.toLowerCase();
      const matchesFilter = activeFilter === "all" || category === activeFilter;
      const matchesQuery = query === "" || haystack.includes(query);
      const visible = matchesFilter && matchesQuery;

      card.hidden = !visible;
      if (visible) visibleCount += 1;
    });

    empty.hidden = visibleCount !== 0;

    if (visibleCount === 0) {
      status.textContent = "No projects found. Try a different search or filter.";
      return;
    }

    const filterLabel = activeFilter === "all" ? "all" : activeFilter;
    status.textContent = query
      ? `Showing ${visibleCount} project(s) for "${query}" in ${filterLabel}.`
      : `Showing ${visibleCount} project(s) in ${filterLabel}.`;
  }

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      activeFilter = button.dataset.filter || "all";
      buttons.forEach((btn) => btn.classList.toggle("active", btn === button));
      updateProjects();
    });
  });

  search.addEventListener("input", updateProjects);
  updateProjects();
}

/* ==========================
   Reveal animations
========================== */
function initRevealAnimations() {
  const items = document.querySelectorAll(".reveal");
  if (items.length === 0) return;

  if (!("IntersectionObserver" in window)) {
    items.forEach((item) => item.classList.add("visible"));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  items.forEach((item) => observer.observe(item));
}

/* ==========================
   Contact form validation (no backend)
========================== */
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showError(fieldId, message) {
  const small = document.querySelector(`small.error[data-for="${fieldId}"]`);
  if (small) small.textContent = message || "";
}

function initContactForm() {
  const form = $("contactForm");
  const status = $("formStatus");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = $("name").value.trim();
    const email = $("email").value.trim();
    const message = $("message").value.trim();

    let ok = true;

    if (name.length < 2) {
      showError("name", "Please enter your name (at least 2 characters).");
      ok = false;
    } else {
      showError("name", "");
    }

    if (!isValidEmail(email)) {
      showError("email", "Please enter a valid email address.");
      ok = false;
    } else {
      showError("email", "");
    }

    if (message.length < 10) {
      showError("message", "Message should be at least 10 characters.");
      ok = false;
    } else {
      showError("message", "");
    }

    if (!ok) {
      if (status) {
        status.textContent = "Please fix the errors above.";
        status.className = "form__status error-state";
      }
      return;
    }

    if (status) {
      status.textContent = "Thanks! Your message is ready to be sent (no backend in this assignment).";
      status.className = "form__status success-state";
    }

    form.reset();
  });
}

/* ==========================
   Init
========================== */
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initThemeToggle();
  initMobileNav();
  initProjectFilters();
  initRevealAnimations();
  initContactForm();
  setGreeting();
  setYear();
});
